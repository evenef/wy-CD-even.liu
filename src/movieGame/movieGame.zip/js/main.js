var butNum = 0,
upBtnC = '',
gameId = 0,
videoCode = '',
FILM_ID = '',
CAT_ID = ''

window.onload = function(){

	initPage(butNum)
	controlVideo('onWatch')
	document.onkeydown = keyFnc

	getEl("#get_play_url").onload = function(){
		var textStr = window.frames["get_play_url"].document.body.innerText;
		// var _mediaUrl = eval('(' + textStr + ')');
		var _mediaUrl = JSON.parse(textStr)
		playUrl = _mediaUrl.playurl;
		playMediaEPG(20, 146, 550, 265)

		getEl('.play_icon').style.display = 'none'
		getEl('#left_video_img').style.display = 'none'
	}
}
var butItems = []

//初始化页面
function initPage(num){
	butItems = []
	for(var i = 0;i < getEl('.list').children.length;i++){
		if(/item/.test(getEl('.list').children[i].className)){
			butItems.push(getEl('.list').children[i])
			getEl('.list').children[i].className = (i - 5) === num ? 'item item_focus' : 'item'
			getEl('.list').children[i].style.backgroundImage = getEl('.list').children[i].style.backgroundImage.replace(/focused/g, 'normal')
		}
	}
	if(typeof(num) === 'undefined')
		return
	switch(num){
		case 0:
		focusImgs('AoTeMan')
		break
		case 1:
		focusImgs('GuoBao')
		break
		case 2:
		focusImgs('KaiJia')
		break
		case 3:
		focusImgs('XiaoMoXian')
		break
		default:
		focusImgs()
		break
	}
}

//选择界面变化样式
function focusImgs(name, obj){
	name = name || ''
	obj = obj || {}
	obj = {
		butImg: obj.butImg || './img/ao_te_man_focused.png',
		logoImg: obj.logoImg || './img/ao_te_man_logo.png',
		bgImg: obj.bgImg || './img/ao_te_man_bgv.png',
		playImg: obj.playImg || './img/ao_te_man_img.png',
		videoImg: obj.videoImg || './img/ao_te_man_video.png'
	}
	switch(name){
		case 'AoTeMan':
		obj = {
			butImg: './img/ao_te_man_focused.png',
			logoImg: './img/ao_te_man_logo.png',
			bgImg: './img/ao_te_man_bgv.png',
			playImg: './img/ao_te_man_img.png',
			videoImg: './img/ao_te_man_video.png'
		}
		break
		case 'GuoBao':
		obj = {
			butImg: './img/guo_bao_te_gong_focused.png',
			logoImg: './img/guo_bao_te_gong_logo.png',
			bgImg: './img/guo_bao_te_gong_bgv.png',
			playImg: './img/guo_bao_te_gong_img.png',
			videoImg: './img/guo_bao_te_gong_video.png'
		}
		break
		case 'KaiJia':
		obj = {
			butImg: './img/kai_jia_yong_shi_focused.png',
			logoImg: './img/kai_jia_yong_shi_logo.png',
			bgImg: './img/kai_jia_yong_shi_bgv.png',
			playImg: './img/kai_jia_yong_shi_img.png',
			videoImg: './img/kai_jia_yong_shi_video.png'
		}
		break
		case 'XiaoMoXian':
		obj = {
			butImg: './img/xiao_mo_xian_focused.png',
			logoImg: './img/xiao_mo_xian_logo.png',
			bgImg: './img/xiao_mo_xian_bgv.png',
			playImg: './img/xiao_mo_xian_img.png',
			videoImg: './img/xiao_mo_xian_video.png'
		}
		break
	}
	getEl('.item_focus').style.backgroundImage = 'url(' + obj.butImg + ')'
	getEl('.item_focus').style.backgroundPosition = 'center'
	getEl('.show_img').style.backgroundImage = 'url(' + obj.logoImg + ')'
	getEl('.bg').style.backgroundImage = 'url(' + obj.bgImg + ')'
	if(obj.playImg){
		getEl('.play_icon').style.display = ''
		getEl('#right_game_img').style.display = ''
		getEl('#right_game_img').src = obj.playImg
	}else{
		getEl('#right_game_img').style.display = 'none'
	}
	if(obj.videoImg){
		getEl('#left_video_img').style.display = ''
		getEl('#left_video_img').src = obj.videoImg
	}else{
		getEl('#left_video_img').style.display = 'none'
	}
}
//选择观影/游戏
function watchOrPlay(name){
	upBtnC = name
	getEl('.left_vedio').children[1].className = 'item'
	getEl('.right_game').children[0].className = 'item'
	if(upBtnC === 'watch'){
		getEl('.left_vedio').children[1].className = 'item itemC'
	}else if(upBtnC === 'play'){
		getEl('.right_game').children[0].className = 'item itemC'
	}
}

//键盘焦点移动
function keyFnc(e){
	switch(e.keyCode){
		case 37:
		if(!upBtnC && butNum){
			destoryMP()
			initPage(--butNum)
			controlVideo('onWatch')
		}else
			watchOrPlay('watch')
		break
		case 38:
		if(butNum <= 1){
			getEl('.item_focus').className = 'item'
			// initPage()
			watchOrPlay('watch')
		}else{
			getEl('.item_focus').className = 'item'
			// initPage()
			watchOrPlay('play')
		}
		break
		case 39:
		if(!upBtnC && butNum < 3){
			destoryMP()
			initPage(++butNum)
			controlVideo('onWatch')
		}else
			watchOrPlay('play')
		break
		case 40:
		watchOrPlay()
		// initPage(butNum)

		// for(var i = 0;i < getEl('.list').children.length;i++){
		// 	if(/item/.test(getEl('.list').children[i].className)){
		// 		butItems.push(getEl('.list').children[i])
		// 		getEl('.list').children[i].className = (i - 5) === num ? 'item item_focus' : 'item'
		// 		getEl('.list').children[i].style.backgroundImage = getEl('.list').children[i].style.backgroundImage.replace(/focused/g, 'normal')
		// 	}
		// }
		butItems.map(function(item){
			item.className = (i - 5) === butNum ? 'item item_focus' : 'item'
			item.style.backgroundImage = item.style.backgroundImage.replace(/normal/g, 'focused')
		})
		break
		case 13:
		if(upBtnC && upBtnC === 'watch'){
			controlVideo('goToWatch')
		}else if(upBtnC && upBtnC === 'play'){
			console.log(upBtnC, butNum)

			initGameData()
			startActivity(gameId, searchObj().UserID)
		}else{
			initGameData()
			startActivity(gameId, searchObj().UserID)
		}
		break
		case 32:
		case 8:
		var obj = searchObj()
		if(obj.ReturnURL)
			document.location.href = obj.ReturnURL
		else
			console.log('%c没有找到ReturnURL', 'color: #f0f')
		break
	}
}
//初始化游戏资料
function initGameData(){
	switch(butNum){
		case 0://奥特曼旧时代奇迹
		gameId = 578
		videoCode = '00zlgj00con201509211402326461001'
		FILM_ID = '56529'
		CAT_ID = '10000100000000090000000000004213'
		break
		case 1://果宝特攻
		gameId = 489
		videoCode = '00zlgj00con201604081018086651001'
		FILM_ID = '215506'
		CAT_ID = '10000100000000090000000000004212'
		break
		case 2://新铠甲勇士
		gameId = 581
		videoCode = '00zlgj00con201606241034016391001'
		FILM_ID = '254919'
		CAT_ID = '10000100000000090000000000004212'
		break
		case 3://巴啦啦小魔仙
		gameId = 579
		videoCode = '00zlgj00con201604080945124441001'
		FILM_ID = '210187'
		CAT_ID = '10000100000000090000000000004212'
		break
	}
}
//视频事件（播放、跳转）
function controlVideo(name){
	initGameData()
	try{
		var epgDoman = Authentication.CTCGetConfig("EPGDomain");
		if(name === 'goToWatch'){
			var _url = epgDoman.substring(0,epgDoman.indexOf("Category.jsp")) + "Category.jsp?spVodPlayUrl="+escape("vod_TVDetail.html?TYPE_ID=" + CAT_ID + "&FILM_ID=" + FILM_ID + "&ReturnURL=" + escape(window.location.href))
			document.location.href = _url
		}else if(name === 'onWatch'){

			var _url = epgDoman.split("/EPG")[0]+"/EPG/jsp/gdgaoqing/en/vaitf/getVodPlayUrl.jsp"+"?code=" + videoCode;

			// pageConsole('epgDoman', epgDoman)
			// pageConsole('_url', _url)

			getEl('#get_play_url').src = _url

			// var ifra = document.createElement('iframe')
			// ifra.src = _url
			// ifra.onload = function(){
			// 	pageConsole('_url_param_iframe', ifra.document.body.innerText)
			// }

			// var _url = epgDoman.split("/EPG")[0]+"/EPG/jsp/gdgaoqing/en/vaitf/getVodPlayUrl.jsp"
			// ajax({
			// 	url: _url,
			// 	data: {
			// 		code: videoCode
			// 	},
			// 	success: function(param){
			// 		pageConsole('_url_param_ajax', _url_param)

			// 		var _mediaUrl = JSON.parse(textStr)
			// 		playUrl = _mediaUrl.playurl
			// 		playMediaEPG(20, 146, 550, 265)

			// 		getEl('.play_icon').style.display = 'none'
			// 		getEl('#left_video_img').style.display = 'none'
			// 	},
			// 	fail: function(err){
			// 		pageConsole('err', err)
			// 	}
			// })
		}
	}catch(e){
		pageConsole('epgDoman获取出错', e)
	}
}



// // 影片分类CODE
// String CAT_ID_0 = "10000100000000090000000000004212";//巴啦啦小魔仙
// String CAT_ID_1 = "10000100000000090000000000004212";//果宝特工 第一部
// String CAT_ID_2 = "10000100000000090000000000004212";//铠甲勇士（一）
// String CAT_ID_3 = "10000100000000090000000000004213";//迪迦奥特曼

// // 用于视频详情页
// String FILM_ID_0 = "210187";//巴啦啦小魔仙
// String FILM_ID_1 = "215506";//果宝特工 第一部
// String FILM_ID_2 = "254919";//铠甲勇士（一）
// String FILM_ID_3 = "56529";//迪迦奥特曼

// // 用于视频详情页
// String TYPE_ID_0 = "00zlgj00con201604080945124441000";//巴啦啦小魔仙
// String TYPE_ID_1 = "00zlgj00con201604081018086651000";//果宝特工 第一部
// String TYPE_ID_2 = "00zlgj00con201606241034016391000";//铠甲勇士（一）
// String TYPE_ID_3 = "00zlgj00con201509211402326461000";//迪迦奥特曼

// 用于游戏页面
//------------新ID------------
//    String GAME_ID_0 = "580";//巴啦啦小魔仙 (测试)
//    String GAME_ID_1 = "581";//果宝特攻 (测试)
//    String GAME_ID_2 = "582";//新铠甲勇士 (测试)
//    String GAME_ID_3 = "579";//奥特曼旧时代奇迹 (测试)
//    
// String GAME_ID_0 = "579";//巴啦啦小魔仙 (正试)
// String GAME_ID_1 = "580";//果宝特攻 (正试)
// String GAME_ID_2 = "581";//新铠甲勇士 (正试)
// String GAME_ID_3 = "578";//奥特曼旧时代奇迹 (正试)

// // 用于获取播放地址
// String PLAY_CODE_0 = "00zlgj00con201604080945124441001";//巴啦啦小魔仙
// String PLAY_CODE_1 = "00zlgj00con201604081018086651001";//果宝特工 第一部
// String PLAY_CODE_2 = "00zlgj00con201606241034016391001";//铠甲勇士（一）
// String PLAY_CODE_3 = "00zlgj00con201509211402326461001";//迪迦奥特曼

// // 用于更换图片
// String IMG_URL_0 = "images/bg0.png";
// String IMG_URL_1 = "images/bg1.png";
// String IMG_URL_2 = "images/bg2.png";
// String IMG_URL_3 = "images/bg3.png";

// // 产品信息
// String produceId = "17010915104027000001";

// // 玩吧路径
// //String Wanba_url = "/Wanba/EPG/v1.0.0/index.jsp";
// String Wanba_url = "/Wanba/EPG/v1.0.0/portal.jsp";
// String is_Wanba_flag = "/Wanba/";

